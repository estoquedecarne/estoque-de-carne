<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

$sql = "SELECT * FROM fornecedor";
$resultado = $conn->query($sql);
if ($resultado->num_rows > 0) {
    
    while($row = $resultado->fetch_assoc()) {
      echo "nome: " . $row["nome"]. " - telefone: " . $row["telefone"]. "  - Email : " . $row["email"]. "<br>";
    }
  } else {
    echo "0 results";
  }
  ?>
  <!DOCTYPE html>
<html lang ="pt-br">

    <head>
      <meta charset="utf-8">
    </head>

    <body>

         <h1>Digite o nome do fornecedor que sera deletado</h1>   

         <form method="POST" action="excluirfornecedor.php">  

            <input type="text" name="nome" placeholder="Digite o nome do fornecedor">               
            
            <input type="submit" value="Deletar">

      </form>


</html>