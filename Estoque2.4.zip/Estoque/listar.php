
<!DOCTYPE html>
<html lang ="pt-br">

    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link href="estilo2.css" rel="stylesheet">
  <title>M-STOCK</title>
      <meta charset="utf-8">
    </head>

    <body class="cadastro" style="margin-top: auto;">

    <div id="page">

    <header class="cabecalho">

            <div class="itens">

                <!--Nome do açougue-->
                <a href="home.html" style="color: black;"><h1><strong>FRIGOBETO</strong></h1><br></a>

                <strong>

                    <h1 style="color: black;">Produtos disponíveis<br>no Estoque</h1>
                </strong>

                <?php
                $servidor = "localhost";
                $usuario = "root";
                $senha = "";
                $DB = "mydb";

                $conn = mysqli_connect($servidor,$usuario,$senha,$DB);

                $sql = "SELECT * FROM carne";
                $resultado = $conn->query($sql);
                if ($resultado->num_rows > 0) {
                    
                    while($row = $resultado->fetch_assoc()) {
                      echo "Tipo: " . $row["tipo"]. " - nome: " . $row["nome"]. "  - peso : " . $row["peso"]. "   - unidade : " . $row["unidade"]. " - data: " . $row["dataentrada"]. "Fornecedor:" .$row["fornecedor"]. "<br>";
                    }
                  } else {
                    echo "0 Produtos!";
                  }
                ?>

            </div>

        </header>

    <main class="cabecalho2">

    <div>

        <h1>Deletar Produto</h1>    

         <label><strong>Digite o produto a ser deletado:</strong></label><br>   

         <form class="cadastro" method="POST" action="excluir.php">  

            <input type="text" name="nome"  placeholder="Digite o produto...">               
            
            <input type="submit" value="Deletar">

      </form>

      <h1>Resumo</h1>

      <form class="cadastro" method="POST" action="listartotal.php">  
      Filtro <input type="text" name ="tipo" style="text-transform: lowercase;" placeholder="Ex: fornecedor,nome">
      Busca <input type="text" name ="palavra" style="text-transform: lowercase;" placeholder="Ex: Sadia,picanha">
            <input type="submit" value="pesquisar">

      </form>

      <form class="cadastro" method="" action="home.html">  

        <input type="submit" value="+ Produtos">

      </form>

      <form class="cadastro" method="" action="sobre.html">  

        <input type="submit" value="Sobre">

      </form>

    </div>

</main>

    </body>

    <footer >

<strong>&copy;M-Stock - 2020</strong>

</footer>

</html>