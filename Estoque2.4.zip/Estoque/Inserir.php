<!doctype html>
<html lang="en">
  <head>
    <title>M-Stock</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="estilo2.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="cabecalho">
<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";
$nome =  $_POST['nome'];
$peso =  $_POST['peso'];
$unidade =  $_POST['unidade'];
$data =  $_POST['data'];
$tipo =  $_POST['tipo'];
$nomefornecedor = $_POST['fornecedor'];


$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

if ($conn->connect_error){
    die("falhou" . $conn->connect_error);
}

$sql = "SELECT idcarneboi FROM carne ORDER BY idcarneboi DESC limit 1" ;
$resultado = $conn->query($sql);
$linha = $resultado->fetch_assoc(); 
    
$id =  $linha["idcarneboi"];
$id ++;

$sql = "SELECT nome FROM fornecedor where nome = '{$nomefornecedor}'" ;
$resultado = $conn->query($sql);
    if ($resultado->num_rows > 0) {
        $sql = "INSERT INTO carne (idcarneboi,nome,peso,dataentrada,tipo,unidade,fornecedor) values ('$id','$nome','$peso','$data','$tipo','$unidade','$nomefornecedor')";
        if($conn->query($sql)===TRUE){
            echo "criou";
        }else{
            "erro".$sql."<br>" . $conn->error;
            echo "não criou";
        }       
    }
    else {
        echo "esse fornecedor n existe no nosso cadastro";
    }
    

?>
 <form method="POST" action="listar.php">

<input type="submit" value="Estoque">

</form>

</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
<footer >

<strong>&copy;M-Stock - 2020</strong>

</footer>
</html>
