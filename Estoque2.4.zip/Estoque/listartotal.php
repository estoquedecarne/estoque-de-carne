<form action ="listartotal.php" method="post">

    Filtro <input type="text" name ="tipo" style="text-transform: lowercase;" placeholder="Ex: fornecedor,nome">
    Busca <input type="text" name ="palavra" style="text-transform: lowercase;" placeholder="Ex: Sadia,picanha">
<input type="submit" value="pesquisar"><br><br>
<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";
$palavra = $_POST['palavra'];

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);


if($_POST['palavra'] != '')
{
    
    $tipo = $_POST['tipo'];
    $palavra = $_POST['palavra'];
    
    $sql = "SELECT COUNT(*) AS contador,nome,SUM(peso) as total FROM carne where {$tipo} = '{$palavra}' GROUP BY nome HAVING COUNT(*) > 0 ";
    $resultado = $conn->query($sql);
    while($row = $resultado->fetch_assoc()) {
        echo "Quantidade: " . $row["contador"]. " |Nome: " . $row["nome"]." |Peso: " . $row["total"]."<br>";
    }
    
    $sql = "SELECT SUM(peso) as total FROM carne WHERE {$tipo} = '{$palavra}' ";
    $resultado = $conn->query($sql);
    $row = $resultado->fetch_assoc();
    echo "peso total: " . $row["total"]. "<br>";
   
}
  
else{
    
    $sql = "SELECT COUNT(*) AS contador,nome,SUM(peso) as total FROM carne  GROUP BY nome HAVING COUNT(*) > 0 ";
    $resultado = $conn->query($sql);
    while($row = $resultado->fetch_assoc()) {
        echo "Quantidade: " . $row["contador"]. " |Nome: " . $row["nome"]." |Peso: " . $row["total"]."<br>";
    }
    
    $sql = "SELECT SUM(peso) as total FROM carne";
    $resultado = $conn->query($sql);
    $row = $resultado->fetch_assoc();
    echo "peso total: " . $row["total"]. "<br>";
}
?>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<form>
<input type="button" value="Imprimir" onClick="window.print()"/>
</form>



