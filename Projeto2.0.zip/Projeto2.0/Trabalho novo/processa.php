<?php

include_once("conexao.php");

$nome =  filter_input(INPUT_POST, 'nome');
$peso =  filter_input(INPUT_POST, 'peso');

echo "Nome: $nome <br>";
echo "peso da carne: $peso <br>";

$cadastroboi =  "INSERT INTO carneboi (nome, peso) VALUES ('3','$nome','$peso')";
$resultado_carneboi = mysqli_query($conn, $cadastroboi);