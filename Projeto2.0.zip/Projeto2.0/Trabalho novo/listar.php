<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

$sql = "SELECT * FROM carneboi";
$resultado = $conn->query($sql);
if ($resultado->num_rows > 0) {
    
    while($row = $resultado->fetch_assoc()) {
      echo "id: " . $row["idcarneboi"]. " - nome: " . $row["nome"]. "  - peso : " . $row["peso"]. "<br>";
    }
  } else {
    echo "0 results";
  }