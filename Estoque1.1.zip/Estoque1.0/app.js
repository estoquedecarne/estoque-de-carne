function leDados (){
    let strdados = localStorage.getItem('db');
    let objDados = {};

    if (strdados) {
        objDados = JSON.parse (strdados);
    

   }
   else {
       objDados = {cadastro: [
           {peso: "50"},
           {peso: "30"}

        ]}
   }
   return objDados;
}
function salvaDados (dados){
localStorage.setItem ('db', JSON.stringify(dados));

}
function incluirCadastro (){   
   let objDados = leDados();
   let strpeso = document.getElementById('peso').Value;
   let novoCadastro = {
       peso:strpeso
      

   };
   objDados.cadastro.push (novoCadastro);

   salvaDados (objDados);

}
function imprimeDados (){
    let tela = document.getElementById('tela');
    let strHtml ='';
    let objDados = leDados();
     for (var i=0;i<objDados.cadastro.length; i++){
         strHtml += `<p>${objDados.cadastro[i].peso}</p>`
     }
     tela.innerHTML = strHtml;

}

document.getElementById('btnCarregaDadosCadastroBoi').addEventListener ('click', imprimeDados);
document.getElementById('btcCadastrarBoi').addEventListener ('click', incluirCadastro);
