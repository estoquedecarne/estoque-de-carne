<?php 
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";
$login = $_POST['login'];
$entrar = $_POST['entrar'];
$Senha = $_POST['senha'];

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);



if ($conn->connect_error){
    die("falhou" . $conn->connect_error);
}

 
           
$sql = "SELECT * FROM usuarios WHERE login ='$login' AND senha = '$Senha'";
$resultado = $conn->query($sql);

      if ($resultado->num_rows <= 0){
        echo"usuario incorreto";
       
      }else{      
        header("Location:Home.html");
      }
  
?>