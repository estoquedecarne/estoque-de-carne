<?php 
$login = $_POST['usuario'];
$Senha = $_POST['senha'];
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);



if ($conn->connect_error){
    die("falhou" . $conn->connect_error);
}



$sql = "SELECT * FROM usuarios WHERE login = '{$login}'";
$resultado = $conn->query($sql);

if($resultado->num_rows > 0) {
    echo 'Já existe!';

  } else{
    $sql = "INSERT INTO usuarios (login,senha) VALUES ('$login','$Senha')";
    
    if($conn->query($sql)===TRUE){      
        echo "criou";
    }else{
        "erro".$sql."<br>" . $conn->error;
        echo "não deu";
    }
  }

    

?>