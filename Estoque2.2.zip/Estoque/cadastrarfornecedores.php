<?php 
$nome = $_POST['Fornecedor'];
$telefone = $_POST['telefone'];
$Email = $_POST['Email'];
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);



if ($conn->connect_error){
    die("falhou" . $conn->connect_error);
}



$sql = "SELECT * FROM fornecedor WHERE nome = '{$nome}'";
$resultado = $conn->query($sql);

if($resultado->num_rows > 0) {
    echo 'Já existe!';

  } else{
    $sql = "INSERT INTO fornecedor (nome,telefone,email) VALUES ('$nome','$telefone','$Email')";
    
    if($conn->query($sql)===TRUE){        
        echo "criou";
    }else{
        "erro".$sql."<br>" . $conn->error;
        echo "n deu";
    }
  }

    

?>