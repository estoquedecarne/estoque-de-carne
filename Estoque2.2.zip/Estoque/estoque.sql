

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`carneboi`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`carneboi` (
  `idcarneboi` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `peso` DOUBLE NOT NULL,
  PRIMARY KEY (`idcarneboi`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`carnefrango`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`carnefrango` (
  `idcarnefrango` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `peso` DOUBLE NOT NULL,
  PRIMARY KEY (`idcarnefrango`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`carneporco`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`carneporco` (
  `idcarneporco` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `peso` DOUBLE NOT NULL,
  PRIMARY KEY (`idcarneporco`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`usuario` (
  `idusuario` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `carnefrango_idcarnefrango` INT NOT NULL,
  `carneporco_idcarneporco` INT NOT NULL,
  `carneboi_idcarneboi` INT NOT NULL,
  PRIMARY KEY (`idusuario`),
  INDEX `fk_usuario_carnefrango1_idx` (`carnefrango_idcarnefrango` ASC),
  INDEX `fk_usuario_carneporco1_idx` (`carneporco_idcarneporco` ASC),
  INDEX `fk_usuario_carneboi1_idx` (`carneboi_idcarneboi` ASC),
  CONSTRAINT `fk_usuario_carnefrango1`
    FOREIGN KEY (`carnefrango_idcarnefrango`)
    REFERENCES `mydb`.`carnefrango` (`idcarnefrango`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_carneporco1`
    FOREIGN KEY (`carneporco_idcarneporco`)
    REFERENCES `mydb`.`carneporco` (`idcarneporco`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_carneboi1`
    FOREIGN KEY (`carneboi_idcarneboi`)
    REFERENCES `mydb`.`carneboi` (`idcarneboi`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
