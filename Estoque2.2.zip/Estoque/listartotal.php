<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

$sql = "SELECT SUM(peso) as total FROM carneboi";
$resultado = $conn->query($sql);
$row = $resultado->fetch_assoc();
echo "peso total: " . $row["total"]. "<br>";