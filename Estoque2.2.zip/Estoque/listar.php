<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

$sql = "SELECT * FROM carneboi";
$resultado = $conn->query($sql);
if ($resultado->num_rows > 0) {
    
    while($row = $resultado->fetch_assoc()) {
      echo "Tipo: " . $row["tipo"]. " - nome: " . $row["nome"]. "  - peso : " . $row["peso"]. "   - unidade : " . $row["unidade"]. " - data: " . $row["dataentrada"].  "<br>";
    }
  } else {
    echo "0 results";
  }
  ?>
<!DOCTYPE html>
<html lang ="pt-br">

    <head>
      <meta charset="utf-8">
    </head>

    <body>

         <h1>Digite o nome da carne a ser deletada</h1>   

         <form method="POST" action="excluir.php">  

            <input type="text" name="nome" placeholder="Digite o nome da carne">               
            
            <input type="submit" value="Deletar">

      </form>

      <h1>Listar total dos kilos </h1>

      <form method="POST" action="listartotal.php">  

            <input type="submit" value="total das carnes">

      </form>
         
    </body>

</html>