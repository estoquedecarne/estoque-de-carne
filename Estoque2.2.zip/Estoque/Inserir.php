<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$DB = "mydb";
$nome =  $_POST['nome'];
$peso =  $_POST['peso'];
$unidade =  $_POST['unidade'];
$data =  $_POST['data'];
$tipo =  $_POST['tipo'];

echo $unidade;

$conn = mysqli_connect($servidor,$usuario,$senha,$DB);

if ($conn->connect_error){
    die("falhou" . $conn->connect_error);
}

$sql = "SELECT idcarneboi FROM carneboi ORDER BY idcarneboi DESC limit 1" ;
$resultado = $conn->query($sql);
$linha = $resultado->fetch_assoc(); 
    
$id =  $linha["idcarneboi"];
$id ++;

$sql = "INSERT INTO carneboi (idcarneboi,nome,peso,dataentrada,tipo,unidade) values ('$id','$nome','$peso','$data','$tipo','$unidade')";
if($conn->query($sql)===TRUE){
    echo "criou";
}else{
    "erro".$sql."<br>" . $conn->error;
    echo "n deu";
}

$conn->close();
?>