-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 31-Maio-2020 às 23:01
-- Versão do servidor: 8.0.18
-- versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `carneboi`
--

DROP TABLE IF EXISTS `carneboi`;
CREATE TABLE IF NOT EXISTS `carneboi` (
  `idcarneboi` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `peso` double NOT NULL,
  `dataentrada` varchar(40) NOT NULL,
  `tipo` varchar(45) NOT NULL,
  PRIMARY KEY (`idcarneboi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `carneboi`
--

INSERT INTO `carneboi` (`idcarneboi`, `nome`, `peso`, `dataentrada`, `tipo`) VALUES
(2, 'Chande dentro', 90, '22/05/1990', 'Boi'),
(3, 'asa', 80, '31/05/2020', 'Frango'),
(4, 'asa de ', 80, '31/05/2020', 'Frango');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
