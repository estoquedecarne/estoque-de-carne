<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";
$nome =  $_POST['nome'];



$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record
$sql = "DELETE FROM fornecedor WHERE nome = ('$nome')";

if ($conn->query($sql) === TRUE) {
  echo "Deletado com sucesso";
} else {
  echo "Digite o nome do fornecedor: " . $conn->error;
}

$conn->close();
?>